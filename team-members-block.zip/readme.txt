Contributors: bilecky
Tags: block
Stable tag: 0.1.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Description
The Team Members Block plugin, authored by Bilecky (Pawel Bilski), adds a customizable block to your WordPress site that dynamically displays team members. Whether you're running a small business, a non-profit, or a large organization, this plugin makes it easy to showcase your team members in a visually appealing and organized manner. The block can be seamlessly integrated into any page or post, allowing you to map and display team members with ease. For more information, visit Pawel Bilski's website.